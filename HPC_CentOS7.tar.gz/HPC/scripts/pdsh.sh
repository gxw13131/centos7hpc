export PDSH_RCMD_TYPE='ssh'
export WCOLL='/etc/pdsh/machines'

